//
//  ViewController.swift
//  FrameExtractFromVideo
//
//  Created by Pawan iOS on 29/11/2022.
//

import UIKit
import AVFoundation
import AssetsLibrary


class ViewController: UIViewController {

    // MARK: - @IBOutlet & Variables
    @IBOutlet weak var collectionView: UICollectionView!
    
    let imagePickerController = UIImagePickerController()
    var videoUrl:URL? = nil
    var frames:[UIImage] = []
    var generator:AVAssetImageGenerator!
    
    // MARK: - View Controller LifeCycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        collectionView.delegate = self
        collectionView.dataSource = self
        
        collectionView.allowsMultipleSelection = true
        
    }
    
    // MARK: - Action
    @IBAction func selectVideoFromVideo(_ sender: UIButton) {
        imagePickerController.sourceType = .photoLibrary
        imagePickerController.delegate = self
        imagePickerController.mediaTypes = ["public.image", "public.movie"]
        present(imagePickerController, animated: true, completion: nil)
    }
}

// MARK: - UINavigationControllerDelegate, UIImagePickerControllerDelegate
extension ViewController: UINavigationControllerDelegate, UIImagePickerControllerDelegate {
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        videoUrl = info[UIImagePickerController.InfoKey.mediaURL] as! URL
        
        let asset:AVAsset = AVAsset(url:self.videoUrl!)
           let duration:Float64 = CMTimeGetSeconds(asset.duration)
           self.generator = AVAssetImageGenerator(asset:asset)
           self.generator.appliesPreferredTrackTransform = true
           self.frames = []
           for index:Int in 0 ..< Int(duration) {
              self.getFrame(fromTime:Float64(index))
           }
           self.generator = nil
            collectionView.reloadData()
        dismiss(animated: true)
    }
    
    private func getFrame(fromTime:Float64) {
        let time:CMTime = CMTimeMakeWithSeconds(fromTime, preferredTimescale:100)
        let image:CGImage
        do {
           try image = self.generator.copyCGImage(at:time, actualTime:nil)
        } catch {
           return
        }
        self.frames.append(UIImage(cgImage:image))
    }
}

// MARK: - UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout

extension ViewController: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return frames.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = CollectionViewCell.registerCollectionViewCell(collectionView: collectionView, indexPath: indexPath)

        cell.frameImages.image  = frames[indexPath.row]
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 100, height: 100)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let previewViewController = PreviewViewController()
        previewViewController.getImageForPreview = frames
        previewViewController.indexPathOfSelectedImage = indexPath.row
        present(previewViewController, animated: true, completion: nil)
    }
}
